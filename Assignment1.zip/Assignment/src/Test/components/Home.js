import React from 'react';
import ArticleList from './ArticleList';

class Home extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            articles:[]
          }
        
    }

    componentDidMount(){
        const _APP_URL = 'https://newsapi.org/v2/everything?q=bitcoin&apiKey=008c2c412a2b403698bc29a732374513&pageSize=10&page=1';
        fetch(_APP_URL).then(res =>{  
          return res.json()
        }).then(data => {
          this.setState({articles : data.articles})
        }).catch(error => console.error())
      }
  
      componentWillMount(){
        
      }

    
    render(){
        return(  
            <div>
                <ArticleList articleList={this.state.articles} />
            </div>
        );

        
    }
}


export default Home;