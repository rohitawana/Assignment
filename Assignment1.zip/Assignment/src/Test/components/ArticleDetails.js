import React from 'react';


class ArticleDetails extends React.Component{
    constructor(props){
        super(props);
        
    }

    renderDetails(){
        let vd = this.props.viewDet;

            return( <div>
                <section style={{maxWidth:"50%", float:"right", textAlign:"center"}}><div><img style={{maxWidth:"100%"}}  src={vd.urlToImage} />
                    <span><h3>{vd.title}</h3></span>
                    
                </div>
                    </section>
                <section><u><h2>{vd.title}</h2></u>
                <div style={{display:"flex"}}><img style={{maxWidth:"100%",height:"50px", width:"50px", borderRadius:"50px"}}  src={vd.urlToImage} />
                <div style={{margin:"5px 10px"}}><b>Author: </b>{vd.author}
                <h6 style={{margin:"5px 0px"}}>Published On : {vd.publishedAt}</h6>
                </div>
                </div>
            <p><b>Url :</b> <a href="{vd.url}"/> {vd.url}</p>
                    <p>
                    <b>Description :</b> <span>{vd.description}</span>
                    </p>
                    <p>
                    <b>Content :</b> <span>{vd.content}</span>
                    </p>
                </section>
                </div>)        
    }

    render(){
        
        
            return(
            <div>
                {this.renderDetails()}
            </div>
            );
        
        
        
    }
}


export default ArticleDetails;