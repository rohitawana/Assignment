import React from 'react';
import { Link } from 'react-router-dom';

class Navigation extends React.Component{

    componentDidMount(){
    }
    render(){
        return (
            <div style={{padding: "10px 0px",background:"grey",  borderRight: "1px solid #ccc"}}>
                <nav className="nav">
                
                
                <div  style={{fontSize:'1rem', marginLeft:'5px'}}>
                    <a href="tel:7406231676" style={{borderRadius:'25px', color:"white"}}>
                        <i style={{fontSize:'20px',marginLeft:'5px',marginRight:'2px',lineHeight:'inherit'}} className="material-icons">phone_in_talk
                        </i>
                        +91 - 7406231676
                    </a>
                </div>
                </nav>
            </div>
        )
    };
}

export default Navigation;