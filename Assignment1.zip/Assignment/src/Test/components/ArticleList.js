import React from 'react';
import ArticleDetails from './ArticleDetails';

class ArticleList extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            showDetails: false,
            id:0,
            input:''
          };
          this._onButtonClick = this._onButtonClick.bind(this);
          
        
    }

    onChangeHandler(e){
        this.setState({
          input: e.target.value
        })
      }


    _onButtonClick(e) {
        console.log('id is  :: '+e.currentTarget.dataset.id);
        this.setState({
            showDetails: true,
            id:e.currentTarget.dataset.id
        });
      }
    renderList(input){
        if(input == ''){
            let counter = 0;
            return this.props.articleList.map(articles => {
                counter++;
                return (<li key={counter} data-id={counter} onClick={((e)=>this._onButtonClick(e))} style={{listStyle:"none"}}>
                    <p></p>
                    <div style={{fontSize:"20px",color:"blue"}} className="title">{articles.title}</div>
                   <div style={{fontSize:"18px",color:"black"}} className="author">Author : <span style={{fontSize:"18px",color:"grey"}}>{articles.author}</span></div> 
                   <span style={{fontSize:"16px",color:"black"}} className="desc">{articles.description}</span> 
                </li>)
            })
        }
        else{
            let counter = 0;
        return this.props.articleList.filter(articles => (articles.author).includes(input)).map(articles => {
            counter++;
            return (<li key={counter} data-id={counter} onClick={((e)=>this._onButtonClick(e))} style={{listStyle:"none"}}>
                <p></p>
                <div style={{fontSize:"20px",color:"blue"}} className="title">{articles.title}</div>
               <div style={{fontSize:"18px",color:"black"}} className="author">Author : <span style={{fontSize:"18px",color:"grey"}}>{articles.author}</span></div> 
               <span style={{fontSize:"16px",color:"black"}} className="desc">{articles.description}</span> 
            </li>)
        })
        }
        
    }

    render(){
        if(this.props.articleList.length > 0){
            if(this.state.showDetails){
                console.log('this.state.id'+this.state.id);
                console.log(this.props.articleList[(parseInt(this.state.id) - 1) ])
                return (   
                    <ArticleDetails viewDet={this.props.articleList[(this.state.id - 1)]}/>
                );
            }
            else{
                
                    return (  
                        <div style={{paddingTop:"20px"}}>
                        <div style={{float:"right",marginRight:"120px"}}><b>Search By Author : </b><input value={this.state.input} type="text" onChange={this.onChangeHandler.bind(this)}/></div> 
                        <ul>
                            {this.renderList(this.state.input)}
                        </ul>
                        </div>           
                      
                    );
                
                
            }
            
          }
          return (
            <div>Loading...</div>
          );
    }
}


export default ArticleList;