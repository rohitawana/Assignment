import React from 'react';
import {BrowserRouter, Route, Link } from 'react-router-dom';


import Navigation from './components/navigation';
import Home from './components/Home';
import ArticleDetaials from './components/ArticleDetails';



class App extends React.Component{
    constructor(props){
        super(props);
        
    }

    render() {
      return(
        <div>
          <BrowserRouter>
            <div>
              <Navigation />
              <Route path="/" exact component={Home} />
              {/* <Route path="/articleDetaials" component={ArticleDetaials} /> */}
            </div>  
          </BrowserRouter> 
        </div>
      )      
    }

}

export default App;